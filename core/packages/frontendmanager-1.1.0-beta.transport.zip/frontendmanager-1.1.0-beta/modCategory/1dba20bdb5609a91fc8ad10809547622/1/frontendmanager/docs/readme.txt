--------------------
frontendmanager
--------------------
Author: but1head <radionov@me.com>
--------------------

A basic Extra for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/but1head/frontendmanager/issues