<?php

namespace Sterc\FormIt\Service;

class RecaptchaResponse
{
    /** @var boolean $is_valid */
    public $is_valid;
    /** @var string $error */
    public $error;
}
